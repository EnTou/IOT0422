#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
#include "driver_usart.h"
#include "board.h"
#include "stm32f10x_tim.h"

extern float pwm_rate ;
//================================================
int main(void)      
{

	board_init();
	USART1_Config(115200);
	TIM3_Config(1799,1,PWM_M);
	PrintfUsart1("hello stm32\r\n");
	TIM_SetCompare2(TIM3,900);
	while(1);
	return 0;

  }





