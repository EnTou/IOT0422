#ifndef _TYPES_H_
#define _TYPES_H_

#ifndef	NULL
	#define NULL ((void *) 0)
#endif

//================================================

typedef enum
{
	NORMAL_M, EXTI_M, PWM_M
}CONFIG_MODE;

#endif

