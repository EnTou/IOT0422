#ifndef _TYPES_H_
#define _TYPES_H_

#ifndef	NULL
	#define NULL ((void *) 0)
#endif

//================================================

typedef enum
{
	NORMAL_M, NORMAL_TI_M, PWM_M, IC_M, IC_TI_M
}CONFIG_MODE;

#endif

