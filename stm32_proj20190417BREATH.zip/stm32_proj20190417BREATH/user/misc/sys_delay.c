#include "sys_delay.h"



void Sys_DelaynUs(volatile unsigned int nCount)
{
	for(; nCount != 0; nCount--);
}

void Sys_DelaynMs(volatile unsigned int nCount)
{

	unsigned int i,j;

    for(i=0;i<nCount;i++)
    {
    	for(j=0;j<10000;j++);
	}

}

