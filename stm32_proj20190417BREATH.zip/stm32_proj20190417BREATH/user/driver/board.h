#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_tim.h"

#ifndef _BOARDS_H_
#define _BOARDS_H_


#define NVIC_PriorityGroup 	NVIC_PriorityGroup_2

#define LED0_OFF 	(GPIO_WriteBit(GPIOF, GPIO_Pin_6,Bit_RESET))
#define LED1_OFF 	(GPIO_WriteBit(GPIOF, GPIO_Pin_7,Bit_RESET))
#define LED2_OFF 	(GPIO_WriteBit(GPIOF, GPIO_Pin_8,Bit_RESET))
#define LED3_OFF 	(GPIO_WriteBit(GPIOF, GPIO_Pin_9,Bit_RESET))

#define LED0_ON 		(GPIO_WriteBit(GPIOF, GPIO_Pin_6,Bit_SET))
#define LED1_ON 		(GPIO_WriteBit(GPIOF, GPIO_Pin_7,Bit_SET))
#define LED2_ON 		(GPIO_WriteBit(GPIOF, GPIO_Pin_8,Bit_SET))
#define LED3_ON 		(GPIO_WriteBit(GPIOF, GPIO_Pin_9,Bit_SET))

#define LED2_PC_ON 		(GPIO_WriteBit(GPIOE, GPIO_Pin_5,Bit_RESET))
#define LED2_PC_OFF 	(GPIO_WriteBit(GPIOE, GPIO_Pin_5,Bit_SET))
#define LED3_PC_ON 		(GPIO_WriteBit(GPIOB, GPIO_Pin_5,Bit_RESET))
#define LED3_PC_OFF 	(GPIO_WriteBit(GPIOB, GPIO_Pin_5,Bit_SET))

#define BUTTON_USER 	(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3))

#define BUTTON_UP 		(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_11))
#define BUTTON_DOWN 	(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_14))
#define BUTTON_LEFT 	(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_7))
#define BUTTON_RIGHT 	(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_15))
#define BUTTON_OK 		(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_8))


extern void board_Init(void);




#endif
