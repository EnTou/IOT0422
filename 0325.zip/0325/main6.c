#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
//glob
int flag = 1;

int file_size(FILE *fp)
{
    int size, ch = 0;
    while(1)
    {
        if(fseek(fp, 0, SEEK_END))
        {
            printf("Fseek failed!\r\n");
            return 0;
        }
        size = ftell(fp);
        while(0)
        {
            ch = fgetc(fp);
            printf("ch:%c\r\n", ch);
            if(EOF != ch)
            {
                size++;
            }
            else break;
        }
        return size;
    }
    //EOF 
}

void *p_fread(void *a)
{
    FILE *fp = (FILE *)a;
    int size, size_last, ch = 0;
    // printf("a:%p fp:%p\r\n", a,fp);
    while(1)
    {
        if(!flag)
        // size = file_size(fp);
        // if((size - size_last) > 0)
        {
            if(fseek(fp, -1, SEEK_CUR))
            {
                printf("Fseek failed!\r\n");
                return 0;
            }
            ch = fgetc(fp);
            printf("a_read:%c\r\n", ch);
            flag = 1;
            // w_time = fwrite(&((char)ch), 1, 1, fp);
            // if(w_time == 0)
            // {
            //     printf("Fwrite failed!\r\n");
            //     return 0;
            // }
        }
        // size_last = size;   
    }
    return 0;
}

int main(int argc, char** argv)
{
    FILE *fp1 = NULL, *fp2 = NULL;
    char write_buf[10] = "Hello";
    char read_buf[10] = {0};
    int w_time, r_time = 0;
    pthread_t id_read = 0;
    int pcr, i = 0;

    fp1 = fopen("./a.txt", "w+");
    fp2 = fopen("./b.txt", "w+");
    if(NULL == fp1)
    {
        printf("Open file1 failed!\r\n");
        return 0;
    }
    if(NULL == fp2)
    {
        printf("Open file2 failed!\r\n");
        return 0;
    }
    pcr = pthread_create(&id_read, NULL, p_fread, fp1);
    if(-1 == pcr)
    {
        printf("pthread create failed\r\n");
        return 0;
    }
//judge file inner pointer;  judge file size changing
    while(*(write_buf+i))
    {
        if(flag)
        {
            w_time = fwrite(write_buf+i, 1, 1, fp1);
            if(w_time == 0)
            {
                printf("Fwrite failed!\r\n");
                return 0;
            }
            printf("a_write: %c\r\n", *(write_buf+i));
            i++;
            flag = 0;
        }       
    }
    // printf("fail size: %d\r\n", file_size(fp1)); 
    
    if(-1 == pthread_join(id_read, NULL))
    {
        printf("pthread join failed\r\n");
        return 0;
    }
    pthread_exit(&id_read);
    fclose(fp1);
    fclose(fp2);
    return 0;
}