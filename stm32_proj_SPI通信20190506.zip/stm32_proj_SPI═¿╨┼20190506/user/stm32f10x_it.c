#include "stm32f10x_it.h"
#include <stdio.h>
#include "types.h"
#include "sys_delay.h"

#include "driver_usart.h"
#include "board.h"
u8  *p;
u8 buf1[100] = {0};
u16 length,i,len=0;
float pwm_rate = 1.0;

void HardFault_Handler(void)
{
  /* ������Ӳ������ʱ����˸�� */
	while(1)
	{
		LED0_ON;
		LED1_ON;
		LED2_ON;
		Sys_DelaynMs(1000);
		LED0_OFF;
		LED1_OFF;
		LED2_OFF;
		Sys_DelaynMs(1000);

	}
}


/******************************************************************************/
/*            STM32F10x Peripherals Interrupt Handlers                        

PC -> STM32 : 0xFA length1 0x01 cmd_type  xx ...  0xFA length2 0x01 xx xx... ���ĳ����Ǳ䳤
STM32 ->  PC: ... ��ͷ  length-2 ������Ч����
0xFA 0x03 0xFA 0x05 0xFA 0x03 0x04 0x01 0xFA ... 
���յ������ֽھͽ�ȡ����
�������*/
/******************************************************************************/

/*
void USART1_IRQHandler(void)      //����1 �жϷ������
{	
	if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)//�����Ϊ�˱���STM32 USART ��һ���ֽڷ�����ȥ��BUG 
	{ 
		 USART_ITConfig(USART1, USART_IT_TXE, DISABLE);//��ֹ�����������жϣ� 
	}	
//  �����ж�
	else if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)//�ж�RXNE,�жϲ���
	{
		USART_ClearITPendingBit(USART1,USART_IT_CTS);//    ��������жϱ�־ 
		LED3_PC_ON;

		buf1[length]=USART_ReceiveData(USART1);
        length++;
		//PrintfUsart1("%s",buf1);
        //�������� 
        while(RESET==USART_GetFlagStatus(USART1,USART_FLAG_TC))
        {
             ;
        }
        //��������
        //0xFA  LEN DATA
		LED2_PC_ON;
        p=buf1; 
        for(i=0;i<length;i++)
        {	    
            if(*p==0xFA)
            {
                p++;
                len=*p;	                
                p++;
                for(i=0;i<len-2;i++)
                {
                    switch(*p)
                    {          
                        case 0x01:  LED2_PC_ON;     break;                            
                        case 0x02:  LED3_PC_ON;     break;
                        case 0x03:  LED2_PC_OFF;     break;
                        case 0x04:  LED3_PC_OFF;     break;
                        case 0x05:  LED0_OFF;    break;
                        case 0x06:  LED1_OFF;    break;
                        case 0x07:  LED2_OFF;    break;
                        case 0x08:  LED3_OFF;    break;
                        default : break;
                    }  
                    p++;
                }	               
            }
            else 
            {
                p++;
            }
        }
    }
}
*/

void EXTI2_IRQHandler(void)
{
	static int button_count = 0;
	//��ʱ����ֹ����
	Sys_DelaynMs(100);	
	
	if(EXTI_GetITStatus(EXTI_Line2) != RESET)
	{
		EXTI_ClearITPendingBit(EXTI_Line2);
		button_count++;
		if(1 == button_count%2)
			LED2_PC_ON;
		else
			LED2_PC_OFF;
		Sys_DelaynMs(20);
	}

}

void EXTI9_5_IRQHandler(void)
{
	static int button_count = 0;
	//��ʱ����ֹ����
	Sys_DelaynMs(20);	
/*	if(EXTI_GetITStatus(EXTI_Line7) != RESET)//LEFT  //OK
	{
		EXTI_ClearITPendingBit(EXTI_Line7);
//		Sys_DelaynMs(20);
		LED3_OFF;
	}
*/
	if(EXTI_GetITStatus(EXTI_Line8) != RESET)//OK
	{
		EXTI_ClearITPendingBit(EXTI_Line8);
		button_count++;
		if(1 == button_count%2)
			//LED3_PC_ON;
			LED1_ON;
		else
			//LED3_PC_OFF;
			LED1_OFF;
	}
	Sys_DelaynMs(20);
}

void EXTI15_10_IRQHandler(void) 
{
	//��ʱ����ֹ����
	Sys_DelaynMs(20);	
	if(EXTI_GetITStatus(EXTI_Line13) != RESET)//UP	
	{
		EXTI_ClearITPendingBit(EXTI_Line13);
		LED1_ON;
//		Sys_DelaynMs(20);
	}

	if(EXTI_GetITStatus(EXTI_Line14) != RESET)//DOWN
	{
		EXTI_ClearITPendingBit(EXTI_Line14);
//		Sys_DelaynMs(20);
		LED1_OFF;
	}

	if(EXTI_GetITStatus(EXTI_Line15) != RESET)//RIGHT
	{
		EXTI_ClearITPendingBit(EXTI_Line15);
		LED0_ON;
	}


}

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
void TIM3_IRQHandler(void)
{
	static int j = 1;
	int a = 0;
	
	if ( TIM_GetITStatus(TIM3 , TIM_IT_Update) != RESET ) //���ָ���� TIM �жϷ������
	{	
		TIM_ClearITPendingBit(TIM3 , TIM_FLAG_Update);  //���TIMx���жϴ�����λ:TIM �ж�Դ		
		if(1 == j)
		{
			pwm_rate -= 0.2;//(float)(pwm_rate*10 - 1)/10;
			a = pwm_rate * 10;
			if(0 == a)
			{
				j =2;
			}
			//PrintfUsart1("%d\r\n",a);
		}		
		else if(2 == j)
		{
			pwm_rate += 0.2;//(float)(pwm_rate*10 + 1)/10 ;
			a = pwm_rate * 10;
			if(10 == a)
			{
				j =1;
			}
		}
							
	}	
}

#define PWM_AMOUNT_T 100//us  0.1ms


void TIM2_IRQHandler(void)//1us
{
	static int a = 0, b = 0, sec = 0;
	static uint16_t cnt = 0,t1 = 0, t2 = 0, t1_sec = 0, t2_sec = 0;
#if 0
	static u32 t = 0;
	if ( TIM_GetITStatus(TIM2 , TIM_IT_Update) != RESET ) //���ָ���� TIM �жϷ������
	{	
		TIM_ClearITPendingBit(TIM2 , TIM_FLAG_Update);  //���TIMx���жϴ�����λ:TIM �ж�Դ		 
   
		if(((t++)%PWM_AMOUNT_T)<(PWM_AMOUNT_T*pwm_rate))//4    
		{
			LED3_PC_ON;
		}
		else
		{
			LED3_PC_OFF;
			
		}
	#if 0	
		if(0 == t%PWM_AMOUNT_T)
			t_hx++;
	#else 
		t++;
		if(1000 == t%2000)//4	
			LED3_PC_ON;
		else if(0 == t%2000)
			LED3_PC_OFF;
	#endif
	}	
#else

	if(TIM_GetITStatus(TIM2, TIM_IT_CC1) != RESET) //���ָ���� TIM �жϷ������
	{	
		TIM_ClearITPendingBit(TIM2, TIM_FLAG_CC1);  //���TIMx���жϴ�����λ:TIM �ж�Դ	
		b++;
		cnt = TIM_GetCounter(TIM2);
		if(1 == b%2)
		{
			//cnt1 1s = 1000ms = 1000 000us  a = 10000  1s
			t1 = a*50+(float)((float)cnt/(float)1799)*50;
			t1_sec = sec;
			//����
			//a
		}
		else
		{
			//cnt2
			//����
			//a
			//get time
			t2 = a*50+(float)((float)cnt/(float)1799)*50;
			t2_sec = sec;
			printf("%d s %d us\r\n", t2_sec - t1_sec, t2 - t1);
			printf("%d.%d.%d s\r\n", t2_sec - t1_sec, (t2 - t1)/1000, (t2-t1)%1000);
		}
	}
	if(TIM_GetITStatus(TIM2, TIM_FLAG_Update) != RESET) //���ָ���� TIM �жϷ������
	{
		TIM_ClearITPendingBit(TIM2, TIM_FLAG_Update);  //���TIMx���жϴ�����λ:TIM �ж�Դ	
		a++;
		if(20000 == a)
		{
			sec++;
			printf("%d\r\n", sec);
			a = 0;
		}
	}
	
#endif
}


