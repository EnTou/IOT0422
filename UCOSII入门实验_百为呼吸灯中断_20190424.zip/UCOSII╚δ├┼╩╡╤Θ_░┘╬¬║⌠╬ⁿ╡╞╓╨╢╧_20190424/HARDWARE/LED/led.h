#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_tim.h"

////////////////////////////////////////////////////////////////////////////////// 
//#define LED0 PBout(5)// PB5
//#define LED1 PEout(5)// PE5	

#define LED0 PFout(6)// PF6
#define LED1 PFout(7)// PF7	
#define BUTTON_GET_STATE GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_8)

void LED_Init(void);//��ʼ��
void button_init(void);
void TIM2_Config(u32 arr,u32 psc);
		 				    
#endif

