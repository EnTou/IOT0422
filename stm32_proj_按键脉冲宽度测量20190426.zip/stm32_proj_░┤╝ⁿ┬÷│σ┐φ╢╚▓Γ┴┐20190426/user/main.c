#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
//#include "driver_usart.h"
#include "usart.h"	
#include "board.h"
#include "stm32f10x_tim.h"

void adc_config(void);

//================================================


int main(void)      
{
	extern void board_init(void);
	extern void TIM2_Config(u32 arr,u32 psc,CONFIG_MODE mode);
	
	board_init();
	//USART1_Config(115200);
	uart_init(115200);
	TIM2_Config(1799,1,IC_TI_M); //1800*2/36M=100us

	//adc_config();
	//TIM3_Config(1799,1,PWM_M);
	//PrintfUsart1("hello stm32\r\n");
	//TIM_SetCompare2(TIM3,900);
	
	while(1)
	{
		//LED1_ON;
		//LED2_ON;
		//LED3_ON;
	}
	
	//return 0;
}

void adc_config(void)
{

	ADC_InitTypeDef ADC_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	//ʱ������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	//ADCʱ��
	RCC_ADCCLKConfig(RCC_PCLK2_Div6); // 72Mhz/6 = 12Mhz
	//��ʼ��
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_NbrOfChannel = 1;
	ADC_Init(ADC1, &ADC_InitStructure);
	//����ʱ��
	ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_239Cycles5);// (239.5+12.5)/12M=252/12 = 21us
	//�ж�����
	ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);
	//NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	//ʹ��
	ADC_Cmd(ADC1, ENABLE);

	//�����У׼
	ADC_ResetCalibration(ADC1);
	while(SET == ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);
	while(SET == ADC_GetCalibrationStatus(ADC1));

	//����
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	
}

void ADC1_2_IRQHandler(void)
{
	LED3_ON;
	uint16_t value = 0;
	double v = 0.000000;
	if(SET == ADC_GetITStatus(ADC1, ADC_IT_EOC))
	{
		ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
		value = ADC_GetConversionValue(ADC1);
		v = (double)((double)value/(double)4096)*(double)3.3;
		//PrintfUsart1("%d\r\n", value);
		printf("%lf\r\n", v);
	}
}


