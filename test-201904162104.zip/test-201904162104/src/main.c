//RCC  RCC_APB2ENR    SIB3  1
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_tim.h"
#include "base.h"

/*
#define RCC_ADDR_BASE		0x40021000
#define RCC_APB2ENR_OFFSET	0x18
#define RCC_APB2ENR	(*(volatile unsigned int *)(RCC_ADDR_BASE+RCC_APB2ENR_OFFSET))

//GPIO  GPIO_CRL  GPIO_BSRR
#define GPIOB_ADDR_BASE		0x40010C00
#define GPIO_CRL_OFFSET		0x00
#define GPIO_BSRR_OFFSET	0x10
#define GPIO_ODR_OFFSET		0x0C
#define GPIO_BRR_OFFSET		0x14

#define GPIOB_CRL_ADDR		(*(volatile unsigned int *)(GPIOB_ADDR_BASE+GPIO_CRL_OFFSET))
#define GPIOB_BSRR_ADDR		(*(volatile unsigned int *)(GPIOB_ADDR_BASE+GPIO_BSRR_OFFSET))
#define GPIOB_ODR_ADDR		(*(volatile unsigned int *)(GPIOB_ADDR_BASE+GPIO_ODR_OFFSET))
#define GPIOB_BRR_ADDR		(*(volatile unsigned int *)(GPIOB_ADDR_BASE+GPIO_BRR_OFFSET))
*/
	
#define PWM_AMOUNT_T	100
#define PWM_RATE		1/5
#define LED_LIGHT_TIME	(PWM_AMOUNT_T*PWM_RATE)

#define BREATH_TIME_AMOUNT	2
#define BREATH_LOOP_COUNT	1000
#define BREATH_PER_TIME		(BREATH_TIME_AMOUNT*1000*1000/BREATH_LOOP_COUNT/PWM_AMOUNT_T)

int pwm_rate = 0;
static u32 t_hx = 0;

void TIM3_IRQHandler(void)
{
	static u32 t = 0;

	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)	//检查指定的TIM中断发生与否
	{	
		TIM_ClearITPendingBit(TIM3, TIM_FLAG_Update);	//清除TIMx的中断待处理位：TIM中断源
		if((t++)%PWM_AMOUNT_T<(PWM_AMOUNT_T*pwm_rate))
		{
			led_opr(LED3, OPEN);
		}
		else
		{
			led_opr(LED3, CLOSE);
		}
		if(0 == t%PWM_AMOUNT_T)
			t_hx++;
/*
		if((t++)%PWM_AMOUNT_T<LED_LIGHT_TIME)
			led_opr(LED3, OPEN);
		else 
			led_opr(LED3, CLOSE);
*/
/*
		if(1 == t%2)
			led_opr(LED3, OPEN);
		else if(0 == t%2)
			led_opr(LED3, CLOSE);
*/
		
	}	
}

void delay(int time)
{
	int i, j;
	for(i = 0; i < time; i++)
		for(j = 0; j < 1000; j++);
}

void EXTI9_5_IRQHandler(void)
{
	static int button_count = 0;
	if(EXTI_GetITStatus(EXTI_Line8) != RESET)
	{
		EXTI_ClearITPendingBit(EXTI_Line8);
		button_count++;
		if(1 == button_count%2)
			led_opr(LED3, OPEN);
		else
			led_opr(LED3, CLOSE);
	}
}

int main(void)
{
#if 0
/*
	volatile unsigned int *gpiob_crl = (unsigned int *)GPIOB_CRL_ADDR;
	volatile unsigned int *gpiob_bsrr = (unsigned int *)GPIOB_BSRR_ADDR;
	
	RCC_APB2ENR = 0x00000008;	//00000000 00000000 00000000 00001000    0x00000008
	GPIOB_CRL_ADDR = 0x00300000;  //0000 0000  0011 0000  0000 0000  0000 0000    0x0030 0000
	//GPIOB_BSRR_ADDR = 0x00200000;  //0000 0000  0010 0000  0000 0000  0000 0000    0x0020 0000
	GPIOB_BSRR_ADDR = 0x00000020;  //0000 0000  0000 0000  0000 0000  0010 0000    0x0000 0020
	//GPIOB_ODR_ADDR = 0x00000000;  //
	//GPIOB_BRR_ADDR = 0x00000000;  //0000 0000  0000 0000  0000 0000  0010 0000    0x0000 0020


	//GPIO_InitTypeDef button = {0};
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
	//button.GPIO_Mode = GPIO_Mode_IPU;
	//button.GPIO_Pin = GPIO_Pin_8;
	//GPIO_Init(GPIOG, &button);
*/

	EXTI_InitTypeDef button_exti = {0};
	NVIC_InitTypeDef button_nvic = {0};
		
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	base_led_init(LED3);
	base_led_init(LED2);
	base_button_init(BUTTON2);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOG, GPIO_PinSource8);
	
	button_exti.EXTI_Line = EXTI_Line8;	
	button_exti.EXTI_Mode = EXTI_Mode_Interrupt;
	button_exti.EXTI_Trigger = EXTI_Trigger_Falling | EXTI_Trigger_Rising;
	button_exti.EXTI_LineCmd = ENABLE;
	EXTI_Init(&button_exti);

	button_nvic.NVIC_IRQChannel = EXTI9_5_IRQn;
	button_nvic.NVIC_IRQChannelPreemptionPriority = 0;
	button_nvic.NVIC_IRQChannelSubPriority = 0;
	button_nvic.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&button_nvic);

	while(1)
	{
		led_opr(LED2, OPEN);
	}

/*	
	while(0)
	{
		if(1 == BUTTON2_GET_STATE)
		{
			led_opr(LED3, OPEN);
		}
		else
		{
			led_opr(LED3, CLOSE);
		}
	}
*/	
/*	
	while(1)
	{
		GPIO_SetBits(GPIOF, GPIO_Pin_6);
		delay(1000);
		GPIO_ResetBits(GPIOF, GPIO_Pin_6);
		delay(1000);
	}
	//GPIO_WriteBit(GPIOF, GPIO_Pin_6, SET);
	//GPIO_WriteBit(GPIOF, GPIO_Pin_6, RESET);
*/
#else

//================================================\\

	int i = 0;
	base_led_init(LED3);
	base_led_init(LED2);
	//TIM3_Config(17999,1);
	TIM3_Config(17,1);
	
	while(1)
	{
		led_opr(LED2, OPEN);
		for(i=0;i<BREATH_LOOP_COUNT;i++)	//2s  2000 000us	/ 1000 = 2000us[2ms] --pwm_rate > 100us[0.1ms]  20次
		{
			while(0 == t_hx % BREATH_PER_TIME)
				pwm_rate = 1/BREATH_LOOP_COUNT*(BREATH_LOOP_COUNT-i);
		}
	}
	
#endif

	return 0;
}

