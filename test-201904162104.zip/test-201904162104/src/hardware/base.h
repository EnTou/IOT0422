#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_tim.h"

//PF6-LED3
#define LED3_ON GPIO_SetBits(GPIOF, GPIO_Pin_6)
#define LED3_OFF GPIO_ResetBits(GPIOF, GPIO_Pin_6)
#define LED3_GET_STATE GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_6)

//PF7-LED2
#define LED2_ON GPIO_SetBits(GPIOF, GPIO_Pin_7)
#define LED2_OFF GPIO_ResetBits(GPIOF, GPIO_Pin_7)
#define LED2_GET_STATE GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_7)

//PG8-BUTTON2
#define BUTTON2_GET_STATE GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_8)

typedef enum
{
	LED0,LED1,LED2,LED3
}LED_NAME_T;

typedef enum
{
	CLOSE,OPEN,GET_STATE
}LED_OPR_T;

typedef enum
{
	BUTTON0,BUTTON1,BUTTON2
}BUTTON_NAME_T;

void base_led_init(LED_NAME_T led_name);
void base_button_init(BUTTON_NAME_T button_name);
uint8_t led_opr(LED_NAME_T led_name, LED_OPR_T led_opr);
void TIM3_Config(u32 arr,u32 psc);

