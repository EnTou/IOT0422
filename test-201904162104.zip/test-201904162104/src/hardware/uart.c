#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"
#include "base.h"

//APB2  PA9-TX  PA10-RX

void delay(int time)
{
	int i = 0, j = 0;
	for(; i < time; i++)
		for(; j < 1000; j++);
}

int main(void)
{
	char r = 0;
	GPIO_InitTypeDef uart_gpio = {0};
	USART_InitTypeDef uart1 = {0};
		
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
	uart_gpio.GPIO_Mode = GPIO_Mode_AF_PP;
	uart_gpio.GPIO_Pin = GPIO_Pin_9;
	uart_gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &uart_gpio);
	uart_gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	uart_gpio.GPIO_Pin = GPIO_Pin_10;
	GPIO_Init(GPIOA, &uart_gpio);
	uart1.USART_BaudRate = 115200;  //115200  9600
	uart1.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	uart1.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	uart1.USART_Parity = USART_Parity_No;
	uart1.USART_StopBits = USART_StopBits_1;
	uart1.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &uart1);
	USART_Cmd(USART1, ENABLE);

	base_led_init(LED3);
	
	while(1)
	{
		//USART_SendData(USART1, 'a');
		//delay(1000000);
		if(1 == USART_GetFlagStatus(USART1, USART_FLAG_RXNE))
		{
			r = USART_ReceiveData(USART1);
			if(r == 'Y' || r == 'y')
				led_opr(LED3, OPEN);
			else if(r == 'N' || r == 'n')
				led_opr(LED3, CLOSE);
			USART_SendData(USART1, r);			
		}
	}


	return 0;
}
