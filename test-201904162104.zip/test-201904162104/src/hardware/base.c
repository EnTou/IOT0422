#include "base.h"

void base_led_init(LED_NAME_T led_name)
{
	GPIO_InitTypeDef led = {0};

	switch(led_name)
	{
		case LED3:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
			led.GPIO_Mode = GPIO_Mode_Out_PP;
			led.GPIO_Pin = GPIO_Pin_6;
			led.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOF, &led);
		break;
		case LED2:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
			led.GPIO_Mode = GPIO_Mode_Out_PP;
			led.GPIO_Pin = GPIO_Pin_7;
			led.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOF, &led);
		break;
		default:
		break;
	}
}

void base_button_init(BUTTON_NAME_T button_name)
{
	GPIO_InitTypeDef button = {0};

	switch(button_name)
	{
		case BUTTON2:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);

			button.GPIO_Mode = GPIO_Mode_IPD;
			button.GPIO_Pin = GPIO_Pin_8;
			GPIO_Init(GPIOG, &button);
		break;
		default:
		break;
	}
}


uint8_t led_opr(LED_NAME_T led_name, LED_OPR_T led_opr)
{
	switch(led_name)
	{
		case LED3:
			switch(led_opr)
			{
				case OPEN:
					LED3_ON;
				break;
				case CLOSE:
					LED3_OFF;
				break;
				case GET_STATE:
					if(LED3_GET_STATE) return OPEN;
					else return CLOSE;
				//break;
				default:
				break;
			}
		break;
		case LED2:
			switch(led_opr)
			{
				case OPEN:
					LED2_ON;
				break;
				case CLOSE:
					LED2_OFF;
				break;
				case GET_STATE:
					if(LED2_GET_STATE) return OPEN;
					else return CLOSE;
				//break;
				default:
				break;
			}
		break;
		case LED1:

		break;
		case LED0:

		break;
		default:
		break;
	}

	return 0;
}

void TIM3_Config(u32 arr,u32 psc)
{		
		
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;	//定义TIM结构体变量
	NVIC_InitTypeDef NVIC_InitStructure;	//定义NVIC中断结构体

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);	//使能TIM3外设
	TIM_DeInit(TIM3);	//复位时钟TIM3，恢复到初始状态

	TIM_TimeBaseStructure.TIM_Period = arr;	//1KHz，16位的值，最大65536
	TIM_TimeBaseStructure.TIM_Prescaler = psc;	//360分频 即为200KHz，16位的值，最大65536
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;	//计数方式向上计数方式
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1 ;	//TIM3时钟分频
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);	//初始化定时器
		
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);	//清除标志
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);    
	TIM_Cmd(TIM3, ENABLE);	//使能TIM3 
	//定时器3中断的配置		 
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn; 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2; 
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE; 
	NVIC_Init(&NVIC_InitStructure);
}


