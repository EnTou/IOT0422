#define FAMILY_IPV4 AF_INET
#define SERVER_PORT 8080
#define SERVER_IP "192.168.57.128"

#define CLIENT_CONNECT_NUM 20

//#define INADDR_ANY (in_addr_t)0x00000000

typedef unsigned char U8_T;
typedef signed char I8_T;
typedef unsigned int U16_T;
typedef signed int I16_T;

typedef struct 
{
	sockaddr_in my_sockaddr_in;
	U8_T socket_type;
}SOCKET_INFO_T;

typedef struct
{
	struct sockaddr_in client_socket_info ;
	I16_T client_sockelen;
	I16_T client_fd ;
	U8_T recv_buf[512];
}CLIENT_CON_T;

//server:fd sock_info send_buf recv_buf
typedef struct
{
	U16_T socket_fd;
	SOCKET_INFO_T sock_info;
	pthread_t recv_id[CLIENT_CONNECT_NUM];
	pthread_t send_id;
	U8_T send_buf[512];
	CLIENT_CON_T client[CLIENT_CONNECT_NUM];
}SERVER_T;


