#ifndef _TYPES_H_
#define _TYPES_H_

#ifndef	NULL
	#define NULL ((void *) 0)
#endif

//================================================


#endif
