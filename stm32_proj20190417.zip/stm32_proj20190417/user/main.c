#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
#include "driver_usart.h"
#include "board.h"
#include "stm32f10x_tim.h"

extern float pwm_rate ;

//================================================
int main(void)      
{
	float i = 0;
	board_init();
	USART1_Config(115200);
	TIM2_Config(1799, 1);
	
	PrintfUsart1("hello stm32\r\n");

#if 0
	//way1
	while(1)
	{
		for(i=1;i>=0;i-=0.2)
		{
			pwm_rate = i;
			Sys_DelaynMs(100); 
		}
		for(i=0;i<=1;i+=0.2)
		{
			pwm_rate = i;
			Sys_DelaynMs(100);
		}
/*
		pwm_rate = 1;			//��ʼ  ��  100us
		Sys_DelaynMs(100);  
		pwm_rate = 0.4;
		Sys_DelaynMs(100);
		pwm_rate = 0.1;
		Sys_DelaynMs(100);
		pwm_rate = 0;
		Sys_DelaynMs(100);
		pwm_rate = 0.1;
		Sys_DelaynMs(100);
		pwm_rate = 0.4;
		Sys_DelaynMs(100);
		pwm_rate = 1;
		Sys_DelaynMs(100);
*/
	}

	
#else
	//way2
		TIM3_Config(179999,199);//   100ms  1800*2000/36us = 100 000us  
		while(1);
#endif

	return 0;
}





