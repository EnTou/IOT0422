#include <stdio.h>
#include <memory.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
typedef struct sockaddr_in my_sockaddr_in;
#define FAMILY_IPV4 AF_INET
#define CLIENT_PORT 8888
#define CLIENT_IP "127.0.0.1"

#define FAMILY_IPV4 AF_INET
#define SERVER_PORT 8080
#define SERVER_IP "127.0.0.1"
int main(int argc, char** argv)
{
    int client_fd  = 0;
    my_sockaddr_in server_socket_info, client_socket_info;
    // unsigned int client_socketlen = 0;
    memset(&client_socket_info, 0, sizeof(my_sockaddr_in));
    memset(&server_socket_info, 0, sizeof(my_sockaddr_in));
    
    client_fd = socket(FAMILY_IPV4, SOCK_STREAM, 0);
    if(-1 == client_fd)
    {
        printf("socket failed\r\n");
        return 0;
    }
    printf("client socket id: %d\r\n", client_fd);

    client_socket_info.sin_family = FAMILY_IPV4;
    client_socket_info.sin_port = htons(CLIENT_PORT);
    // memcpy(&client_socket_info.sin_addr.s_addr, htonl(CLIENT_IP), sizeof(unsigned long));
    client_socket_info.sin_addr.s_addr = htonl(INADDR_ANY);
    // htonl((unsigned long)CLIENT_IP);

    server_socket_info.sin_family = FAMILY_IPV4;
    server_socket_info.sin_port = htons(SERVER_PORT);
    server_socket_info.sin_addr.s_addr = htonl(INADDR_ANY);
    // server_socket_info.sin_addr.s_addr = htonl((unsigned long)SERVER_IP);

    if(-1 == bind(client_fd, (struct sockaddr *)(&client_socket_info), sizeof(my_sockaddr_in)))
    {
        printf("bind failed\r\n");
        return 0;
    }
    printf("bind success\r\n");

    if(-1 == connect(client_fd, (struct sockaddr *)(&server_socket_info), sizeof(my_sockaddr_in)))
    {
        printf("connect failed\r\n");
        return 0;
    }    
    printf("connect success\r\n");

    return 0;
}